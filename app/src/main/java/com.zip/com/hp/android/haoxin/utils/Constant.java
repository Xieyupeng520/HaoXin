package com.hp.android.haoxin.utils;

public class Constant {
	
	public static final String 	FONT_TYPE_FANGZ = "fangzhtjt.ttf";
	public static final String 	FONT_TYPE_HELVE = "helvetica.ttf";
	
}
