package com.hp.android.haoxin.request;

/**
 * 询问
 * Created by AZZ on 15/8/23 16:32.
 */
public interface iRequest {
    /**
     * 询问
     */
    void onRequest();
}
